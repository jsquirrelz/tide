# Phase 04 — Credential and Chart Wiring

## Objective

Wire the Codex provider's credential path and per-level image configuration
into the TIDE Helm chart — so an operator can declare "Plan/Task levels
dispatch to Codex" with a single `values.yaml` override and the runtime
picks up `OPENAI_API_KEY` from a named K8s Secret with no manifest inlining.

This phase is purely chart-layer work — it consumes the `internal/subagent/codex/`
package (Phases 01–02) and the per-level `ResolveProvider` dispatch fix
(Phase 03) as given infrastructure; it produces no new Go source.

---

## Scope

**In scope:**
- `charts/tide/values.yaml` — new `codex.*` stanza:
  `enabled`, `secretRef.name`, `secretRef.key`, and per-level
  `subagentConfig.levels.{milestone,phase,plan,task}.image` overrides
  that resolve to the Codex image.
- `charts/tide/values.schema.json` — extend JSON schema to validate the
  new stanza; `helm lint` must remain clean.
- RBAC — Role rule granting the subagent ServiceAccount `get` / `list`
  on the operator-supplied Secret, following the existing Anthropic
  `providerSecretRef` RBAC pattern.
- Subagent Job template — conditional `envFrom` / `env` injection of
  `OPENAI_API_KEY` (or `CODEX_API_KEY`) from the referenced Secret when
  the dispatched level is Codex-bound; no injection when the level is
  Anthropic-bound — keeping existing Anthropic wiring untouched.
- `config/samples/tide_v1alpha2_project_codex_demo.yaml` — an end-to-end
  example Project CR demonstrating: Claude at Milestone/Phase levels,
  Codex at Plan/Task levels.

**Out of scope:**
- Go package changes (`internal/subagent/codex/` closed in Phases 01–02).
- Controller or cmd/manager changes (closed in Phase 03).
- CRD schema changes (SubagentConfig already carries per-level LevelConfig).
- Any live API call to OpenAI — all chart-render tests run offline.

---

## Expected Deliverables

| # | Artifact | Path |
|---|----------|------|
| 1 | Helm values — Codex stanza | `charts/tide/values.yaml` |
| 2 | Helm values schema update | `charts/tide/values.schema.json` |
| 3 | RBAC Role/RoleBinding for Codex secret | `charts/tide/templates/rbac.yaml` (or equivalent) |
| 4 | Subagent Job template — Codex secret injection | `charts/tide/templates/subagent-job.yaml` + `charts/tide/templates/_helpers.tpl` |
| 5 | Example mixed-provider Project CR | `config/samples/tide_v1alpha2_project_codex_demo.yaml` |

---

## Verification Gates

1. **`make helm-lint`** — passes with zero new warnings after the `codex.*`
   values stanza is added.
2. **`make helm-template`** — produces a Job spec that includes the
   `OPENAI_API_KEY` `envFrom` reference for a Codex-level subagent job and
   does NOT inject it for Anthropic-level jobs.
3. **`make test`** — remains green; no new OpenAI API call in tests
   without `OPENAI_API_KEY` env guard.
4. **Schema validation** — `helm install --dry-run` against a local cluster
   confirms RBAC rules grant `get`/`list` on the named Secret.
5. **CR validation** — `kubectl apply --dry-run=server` of the sample
   Project CR validates against the v1alpha2 CRD without errors.

---

## Wave Map (illustrative)

| Wave | Plans | Rationale |
|------|-------|-----------|
| 1 | `plan-01-chart-codex-values-schema`, `plan-02-chart-rbac` | No predecessors — values contract and RBAC are independent |
| 2 | `plan-03-chart-job-secret-injection` | Needs values from Wave 1 to template correctly |
| 3 | `plan-04-sample-cr` | Needs full wiring from Waves 1–2 to produce a valid example |

