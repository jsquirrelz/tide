# Phase Brief — phase-01-provider-switch

## Objective

Eliminate the hard-coded `Vendor:"anthropic"` constant from
`ResolveProvider` (internal/controller/dispatch_helpers.go) and replace it
with a per-level vendor read from `SubagentConfig.Levels.<level>.LevelConfig`
— so the controller can dispatch a Task at the Plan level to Codex and a Task
at the Milestone level to Claude within the same Project run without any
provider logic leaking into cmd/manager/ or internal/controller/.

## Scope

This phase owns only the **controller-side** half of the provider switch. The
Codex subagent package (internal/subagent/codex/) and the Helm/Secret wiring
are owned by sibling phases. This phase's deliverables are complete when a
Project CRD with a `task` LevelConfig bearing `vendor: codex` causes the
reconciler to stamp that vendor onto the dispatch envelope and select the
Codex subagent runner — irrespective of which subagent binary actually ships
in later phases.

Three tightly-ordered Plans deliver the switch:

| # | Plan | Wave | Core file(s) |
|---|------|------|--------------|
| 1 | plan-01-vendor-field-schema    | 1 | api/v1alpha2/project_types.go, zz_generated.deepcopy.go |
| 2 | plan-02-resolve-provider-dispatch | 2 | internal/controller/dispatch_helpers.go, task_controller.go (or dispatch job builder) |
| 3 | plan-03-provider-switch-tests  | 3 | internal/controller/dispatch_helpers_test.go |

## Expected Deliverables

- `LevelConfig` carries an explicit `Vendor` string field — empty string
  falls back to `"anthropic"` at runtime; no existing Project CRD requires
  migration.
- `ResolveProvider` reads `LevelConfig.Vendor` and returns the resolved
  `pkg/dispatch.Provider`; zero hardcoded vendor strings remain in
  internal/controller/ or cmd/manager/.
- The dispatch Job builder — wherever it stamps the `provider.vendor` env var
  or envelope field — consumes the output of `ResolveProvider` rather than a
  literal `"anthropic"` string.
- Offline-safe unit tests for the resolution path cover the anthropic-default
  case and the codex-override case; `make test` is green.

## Verification Gates

1. `make test` green — no existing test broken.
2. `make verify-*` green — Apache 2.0 headers, logr/zap logging,
   controller-runtime patterns all satisfied.
3. `grep -r '"anthropic"' internal/controller/` returns zero hits in the
   dispatch path (schema constants are exempt).
4. A Project fixture with `task.vendor: codex` produces a reconciler event
   where `provider.vendor == "codex"` — verified by the new unit test.
5. A Project fixture omitting `vendor` produces `provider.vendor == "anthropic"`
   — backward-compat verified by the same test suite.

## Constraints Inherited

- No Codex imports in internal/controller/ or cmd/manager/ — the vendor string
  is opaque to the controller; the subagent package resolves it at runtime.
- No real OpenAI API call in tests — `OPENAI_API_KEY` guard required if any
  live call is introduced (none expected at this layer).
- Secret material never inlined — the phase touches only the vendor-resolution
  path, not the Secret-mount path (owned by the credential phase).
