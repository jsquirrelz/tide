# Phase Brief — phase-06-hetero-integration

## Objective

Deliver a production-ready Codex (OpenAI) subagent implementation and the
per-level provider switch that together enable real heterogeneous dispatch —
mixed-provider waves that actually execute, not interface scaffolding. A TIDE
operator must be able to configure a `Project` where the planner pool runs
Claude and the executor pool runs Codex; TIDE dispatches a multi-phase run to
completion with correct wave-boundary failure semantics across both providers,
full usage accounting, and budget enforcement, all without any provider
hard-coding leaking outside `internal/subagent/codex/`.

## Scope

This phase builds **only** the new product surface the milestone requires:

- The `internal/subagent/codex/` Go package — four files mirroring the
  anthropic layering pattern (`doc.go`, `client.go`, `run.go`, `pricing.go`).
- The Codex subagent container image (`Dockerfile`) bundling the Codex CLI.
- The per-level provider switch — lifting `ResolveProvider` in
  `internal/controller/dispatch_helpers.go` out of its hardcoded
  `Vendor:"anthropic"` state and deriving vendor from the per-level
  `LevelConfig.Vendor` field added to `api/v1alpha2/project_types.go`; job
  builder updated to mount the correct credential Secret per vendor.
- Helm chart credential wiring — new `codexSecretRef` chart value,
  Secret manifest template, RBAC extension for the new Secret name;
  `OPENAI_API_KEY` surfaced to the Codex pod via Secret ref, never inlined.
- Offline-safe unit tests — usage normalization, pricing table, envelope
  round-trip; live tests gated on `OPENAI_API_KEY` env guard.
- A demo `Project` CR YAML (`config/samples/`) and accompanying
  `docs/heterogeneous-dispatch.md` proving the end-to-end mixed-provider
  story is operable.

**Out of scope:** per-task provider selection, per-project (non-mixing)
selection, any change to the global wave-boundary failure model (Phase 25
semantics are locked and unchanged).

## Expected Deliverables

| # | Deliverable | Owner plan |
|---|-------------|------------|
| 1 | `internal/subagent/codex/{doc,client,run,pricing}.go` | plan-01-codex-core |
| 2 | `internal/subagent/codex/Dockerfile` | plan-02-codex-container |
| 3 | `api/v1alpha2/project_types.go` — `LevelConfig.Vendor` field | plan-03-provider-switch |
| 4 | `internal/controller/dispatch_helpers.go` — vendor-aware `ResolveProvider` | plan-03-provider-switch |
| 5 | `internal/controller/job_builder.go` — per-vendor Secret mount | plan-03-provider-switch |
| 6 | `charts/tide/values.yaml` + Secret template + RBAC delta | plan-04-credential-chart |
| 7 | `internal/subagent/codex/*_test.go` — offline-safe unit tests | plan-05-tests |
| 8 | `config/samples/mixed_provider_project.yaml` + `docs/heterogeneous-dispatch.md` | plan-06-integration-demo |

## Verification Gates

All gates must be green before the phase is marked **Succeeded**:

1. **`make test`** passes without a live OpenAI API key — Codex tests that
   require a real call are guarded by `if os.Getenv("OPENAI_API_KEY") == ""`
   and skip cleanly.
2. **`make verify-*`** (lint, vet, copyright headers) passes — Apache 2.0
   headers on every new `.go` file; `logr`/`zap` logging conventions
   followed; no `Codex` import in `internal/controller/` or `cmd/manager/`.
3. **Provider isolation:** `grep -r "codex\|openai" internal/controller/ cmd/manager/`
   returns zero results (case-insensitive, package-import lines).
4. **Usage non-zero for Codex tasks:** integration smoke confirms
   `pkg/dispatch.Usage.InputTokens > 0` and `EstimatedCostCents > 0` for a
   Codex-dispatched task (verified against the demo Project CR).
5. **Wave-boundary failure semantics:** existing Phase 25 integration tests
   pass unmodified — no new failure-path code paths added for mixed-provider
   waves.
6. **Secret hygiene:** `grep -r "OPENAI_API_KEY\|sk-" charts/` returns zero
   hardcoded values — key appears only in Secret template as a `secretKeyRef`.

## Wave Map (illustrative — authoritative wave derived by Kahn over Task DAG)

```
Wave 1 ── plan-01-codex-core          (no deps)
       ── plan-03-provider-switch     (no deps)

Wave 2 ── plan-02-codex-container     (← plan-01)
       ── plan-04-credential-chart    (← plan-01, plan-03)
       ── plan-05-tests               (← plan-01)

Wave 3 ── plan-06-integration-demo    (← plan-01, plan-02, plan-03,
                                          plan-04, plan-05)
```
