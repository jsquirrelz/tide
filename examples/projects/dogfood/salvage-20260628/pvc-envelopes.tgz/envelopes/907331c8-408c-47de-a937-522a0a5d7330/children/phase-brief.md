# Phase Brief — phase-05-heterogeneous-dispatch-demo

## Objective

Prove — not scaffold — that TIDE executes real mixed-provider waves to
completion: Claude agents plan, Codex agents execute, and the global
wave-boundary failure model (Phase 25) holds unchanged across both
providers. This phase is the capstone integration layer; it assumes
`internal/subagent/codex/` is compiled, the per-level `ResolveProvider`
switch is live in `internal/controller/dispatch_helpers.go`, and the Helm
chart carries Codex credential wiring. Its sole mandate is verification,
demonstration, and operator-facing documentation — no reimplementation of
anything already in main.

## Scope

- **Offline unit-test suite** for `internal/subagent/codex/` — covers usage
  normalization from mock JSON payloads, pricing-table arithmetic, and
  `Client` construction without any network call; every test passes with
  `make test` and no `OPENAI_API_KEY` present.
- **Guarded integration test** for `Subagent.Run()` — invokes the real Codex
  CLI against a live OpenAI endpoint; skipped automatically when
  `OPENAI_API_KEY` is unset; asserts `EnvelopeOut` is populated,
  `Usage.InputTokens > 0`, `EstimatedCostCents > 0`, and any emitted child
  CRDs are valid JSON.
- **Controller-level provider-resolution tests** — unit tests for
  `ResolveProvider` asserting correct `Vendor` is returned for each level
  override; a table-driven suite confirming wave-boundary failure semantics
  are provider-agnostic — no new code paths, only assertions against
  existing Phase 25 logic.
- **Example `Project` CR** — a committed YAML in `config/samples/` that
  pins `Milestone`/`Phase` levels to the Claude image and `Plan`/`Task`
  levels to the Codex image, referencing credential Secrets by name only.
- **Operator runbook** — `docs/heterogeneous-dispatch.md` — declarative
  walk-through of configuring, deploying, and observing a
  mixed-provider project; covers chart values, Secret creation,
  dashboard panels, and budget enforcement.

**Out of scope:** any changes to the Codex package source files, the
Dockerfile, the `ResolveProvider` implementation, the Helm chart templates
themselves, the global DAG assembler, or the Phase 25 wave-boundary
failure logic — all of those are owned by preceding phases and must
arrive in main before this phase's Tasks execute.

## Expected Deliverables

| # | Deliverable | Owner plan |
|---|-------------|------------|
| 1 | `internal/subagent/codex/pricing_test.go` | plan-05-offline-unit-tests |
| 2 | `internal/subagent/codex/client_test.go` | plan-05-offline-unit-tests |
| 3 | `internal/subagent/codex/run_test.go` | plan-05-offline-unit-tests |
| 4 | `internal/subagent/codex/integration_test.go` | plan-05-codex-integration-test |
| 5 | `internal/controller/dispatch_helpers_codex_test.go` | plan-05-dispatch-provider-tests |
| 6 | `config/samples/tide_v1alpha2_project_heterogeneous.yaml` | plan-05-example-project-cr |
| 7 | `docs/heterogeneous-dispatch.md` | plan-05-docs-and-verify |
| 8 | `Makefile` — `verify-hetero` target | plan-05-docs-and-verify |

## Verification Gates

All gates must be green before this phase is marked **Succeeded**:

1. **`make test`** exits 0 with no `OPENAI_API_KEY` set — every Codex test
   that touches a live API bears `if os.Getenv("OPENAI_API_KEY") == "" { t.Skip(...) }`.
2. **`make verify-*`** (lint, vet, copyright) — Apache 2.0 SPDX header on
   every new `.go` file; `logr`/`zap` conventions; no `codex` or `openai`
   import in `internal/controller/` or `cmd/manager/`.
3. **Provider isolation:** `grep -ri "codex\|openai" internal/controller/ cmd/manager/`
   returns zero hits on import lines.
4. **Usage non-zero:** the guarded integration test confirms
   `Usage.InputTokens > 0` and `EstimatedCostCents > 0` for a Codex-
   dispatched invocation.
5. **Wave-boundary semantics:** `ResolveProvider` unit tests confirm correct
   `Vendor` per level; existing Phase 25 tests pass unmodified.
6. **Secret hygiene:** the example Project CR references Secrets by name;
   `grep -r "OPENAI_API_KEY\|sk-" config/samples/` returns zero.

## Wave Map (illustrative — authoritative wave derived by Kahn over Task DAG)

```
Wave 1 ── plan-05-offline-unit-tests      (no deps)
       ── plan-05-example-project-cr      (no deps)

Wave 2 ── plan-05-codex-integration-test  (← plan-05-offline-unit-tests)
       ── plan-05-dispatch-provider-tests (← plan-05-offline-unit-tests)

Wave 3 ── plan-05-docs-and-verify         (← plan-05-example-project-cr,
                                              plan-05-codex-integration-test,
                                              plan-05-dispatch-provider-tests)
```
