# Phase Brief — phase-02-codex-subagent

## Objective

Implement the `internal/subagent/codex/` Go package — the complete, production-ready
Codex (OpenAI) subagent that satisfies the `pkg/dispatch.Subagent` interface and
integrates transparently with the existing budget, telemetry, and DAG machinery.
This phase delivers the Go source only; the container image (Dockerfile), credential
wiring, and per-level vendor switch are upstream or downstream concerns that this
phase intentionally does not own.

## Scope

All new code lives exclusively under `internal/subagent/codex/`; no imports of
Codex-specific types are permitted in `internal/controller/`, `cmd/manager/`, or
`pkg/dispatch/`. The package mirrors the D-C1 layering pattern established by
`internal/subagent/anthropic/` — `client.go` owns CLI invocation and JSONL
parsing, `run.go` owns the `Subagent` adapter and Usage normalization, `pricing.go`
owns the per-model cost table, and `doc.go` declares the package contract. Unit
tests must pass offline (no live OPENAI_API_KEY required unless the env var is
explicitly set).

## Expected Deliverables

| File | Purpose |
|------|---------|
| `internal/subagent/codex/doc.go` | Package-level doc referencing D-C1 pattern; Apache 2.0 header |
| `internal/subagent/codex/pricing.go` | Per-model cents/MTok table; `ComputeCost(model, in, out, cacheRead int64) Usage` |
| `internal/subagent/codex/client.go` | `Client` struct; constructor; `exec()` — invokes `codex exec --json --ephemeral --skip-git-repo-check --ignore-user-config --sandbox workspace-write`; parses JSONL event stream; extracts final message + raw usage block |
| `internal/subagent/codex/run.go` | `Subagent` adapter; `Run(ctx, EnvelopeIn) (EnvelopeOut, error)`; normalises OpenAI usage → `pkg/dispatch.Usage` (prompt_tokens→InputTokens, completion_tokens→OutputTokens, cached_tokens→CacheReadTokens, CacheCreationTokens=0); delegates cost to pricing table |
| `internal/subagent/codex/run_test.go` | Offline unit tests — pricing correctness, Usage normalisation, client construction; OPENAI_API_KEY guard for any live call |
| `internal/subagent/codex/client_test.go` | JSONL parsing tests against fixture event streams; no network calls |

## Verification Gates

1. `make test` passes with zero failures — including the new `internal/subagent/codex/...` packages — in an environment without `OPENAI_API_KEY`.
2. `go vet ./internal/subagent/codex/...` reports no errors.
3. `make verify-lint` (or equivalent `golangci-lint`) passes — Apache 2.0 header present on every file, logr/zap logging throughout, no `fmt.Print*` in production code.
4. `go build ./internal/subagent/codex/...` compiles clean; the package is importable as a `pkg/dispatch.Subagent` implementation without touching any controller or manager package.
5. Pricing table covers at minimum: `codex-1`, `codex-1-mini`; `ComputeCost` returns `EstimatedCostCents > 0` for non-zero token counts and `CacheSavingsCents > 0` when `cacheRead > 0`.
6. `CacheCreationTokens` is explicitly 0 in all Usage outputs — OpenAI automatic caching has no creation concept.

## Wave Structure (illustrative)

| Wave | Plans | Rationale |
|------|-------|-----------|
| 1 | plan-01-scaffold, plan-02-pricing | Foundation — no inter-plan deps; parallelisable |
| 2 | plan-03-client, plan-04-run | Build on scaffold + pricing; client precedes run |
| 3 | plan-05-tests | Validates the completed package; depends on all prior plans |

> Authoritative execution waves are derived by Kahn over the Task DAG; the table
> above is the human-readable intent encoded in `dependsOn`.
