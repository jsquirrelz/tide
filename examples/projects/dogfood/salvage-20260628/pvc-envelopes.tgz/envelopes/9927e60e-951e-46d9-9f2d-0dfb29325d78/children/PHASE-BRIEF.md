# Phase Brief — phase-01-codex-pricing-usage

## Objective

Lay the accounting foundation for the Codex subagent — implement the
per-model pricing table and the OpenAI usage-normalization layer that every
other phase depends on for correct `pkg/dispatch.Usage` population. Without
these two files, budget enforcement reads $0 and the dashboard's
cache-efficiency panel is blank for all Codex tasks; no later phase can claim
correctness until this one is green.

## Scope

Two new Go source files in `internal/subagent/codex/` plus their offline-safe
unit tests. No controller changes, no Dockerfile, no chart values — those
belong to later phases. Provider leakage is forbidden: nothing in
`internal/controller/` or `cmd/manager/` imports this package.

## Expected Deliverables

| File | Content |
|---|---|
| `internal/subagent/codex/pricing.go` | Per-model pricing table — `EstimateCost(model, inputTok, outputTok, cacheReadTok int64) (costCents, savingsCents float64)`. Must cover `codex-1`, `codex-1-mini`, `gpt-4o`; cacheRead rate = 50 % of input rate (OpenAI's automatic cached-input discount). Apache 2.0 header. |
| `internal/subagent/codex/usage.go` | `openAIUsage` struct mirroring the OpenAI API usage block + `NormalizeUsage(model string, u openAIUsage) pkg/dispatch.Usage`. Maps `prompt_tokens → InputTokens`, `completion_tokens → OutputTokens`, `prompt_tokens_details.cached_tokens → CacheReadTokens`; leaves `CacheCreationTokens = 0` (OpenAI caching is automatic/marker-free — no cache_control concept). Calls `EstimateCost` for `EstimatedCostCents` and `CacheSavingsCents`. |
| `internal/subagent/codex/pricing_test.go` | Table-driven unit tests — every model returns non-zero cost; zero tokens → zero cost; cache savings ≥ 0. Offline-safe; no `OPENAI_API_KEY` guard needed. |
| `internal/subagent/codex/usage_test.go` | Table-driven unit tests — `CacheCreationTokens == 0` invariant; `CacheReadTokens` mirrors `cached_tokens`; `EstimatedCostCents > 0` when tokens > 0. Offline-safe. |

## Verification Gates

1. `make test` is green (no real API calls anywhere in this phase).
2. `make verify-*` passes — Apache 2.0 headers present, lint clean.
3. `EstimateCost` returns `(> 0, ≥ 0)` for every model in the table when
   inputTok = 1_000_000.
4. `NormalizeUsage` unit test asserts `CacheCreationTokens == 0` on every
   fixture — this invariant distinguishes Codex from Anthropic and must be
   tested explicitly.
5. No import of this package appears in `internal/controller/` or
   `cmd/manager/` (checked by `grep` or `go list` in CI).

## Wave Groupings (illustrative)

| Wave | Plans |
|---|---|
| 1 | plan-01-codex-pricing-table |
| 2 | plan-02-codex-usage-normalizer |
| 3 | plan-03-codex-pricing-usage-tests |

Authoritative execution waves are derived by Kahn over the Task DAG;
these groupings are informational.
