# Phase Brief — phase-01-codex-subagent-core

## Objective

Establish the complete `internal/subagent/codex/` Go package — the provider-isolated
implementation of `pkg/dispatch.Subagent` that drives Codex (OpenAI) headless execution
pods. This phase delivers the entire runtime-facing surface: package scaffolding, the
`Client` constructor that resolves `OPENAI_API_KEY` from the Secret-ref credential path,
the `Subagent.Run()` loop that invokes `codex exec` headlessly and parses its JSONL event
stream, and the per-model pricing table that normalises OpenAI token usage into the
provider-neutral `pkg/dispatch.Usage` struct. No Codex-specific symbol may cross
the package boundary into `internal/controller/` or `cmd/manager/`; the `pkg/dispatch.Subagent`
interface is the sole seam.

## Scope

- `internal/subagent/codex/doc.go` — package-level doc comment citing the D-C1
  layering pattern and the spec's provider-isolation requirement.
- `internal/subagent/codex/client.go` — `Client` struct (holds model name, credential
  env-var name, sandbox flags) + `NewClient(cfg LevelConfig) (*Client, error)` constructor.
  Resolves the API key from the K8s Secret env injection — never reads host config files.
- `internal/subagent/codex/pricing.go` — `PricingTable` mirroring
  `internal/subagent/anthropic/pricing.go`; entries keyed by model slug; fields:
  InputCentsPerMTok, OutputCentsPerMTok, CacheReadCentsPerMTok (OpenAI's
  50 %-discounted cached-input rate); `Compute(model string, u Usage) CostResult`.
- `internal/subagent/codex/run.go` — `Subagent` struct embedding `*Client`;
  `Run(ctx context.Context, in pkg/dispatch.EnvelopeIn) (pkg/dispatch.EnvelopeOut, error)`
  invokes `codex exec --ephemeral --skip-git-repo-check --ignore-user-config --json
  --sandbox workspace-write [--output-schema <schema-file>] <prompt>`, streams JSONL,
  normalises the terminal `message` event into `EnvelopeOut`, and populates
  `pkg/dispatch.Usage` (InputTokens ← prompt_tokens, OutputTokens ← completion_tokens,
  CacheReadTokens ← prompt_tokens_details.cached_tokens, CacheCreationTokens = 0,
  EstimatedCostCents + CacheSavingsCents via pricing table).
- `internal/subagent/codex/run_test.go` — unit tests driven by a mock `codex`
  binary or pre-recorded JSONL fixtures; all tests pass offline and require no
  `OPENAI_API_KEY`. Any live-call test is gated on `os.Getenv("OPENAI_API_KEY") != ""`.
- `internal/subagent/codex/pricing_test.go` — table-driven tests for every model
  entry and the CacheSavingsCents formula; fully offline.

## Out of Scope for This Phase

- The `Dockerfile` / container image — owned by `phase-02`.
- The per-level vendor switch in `internal/controller/dispatch_helpers.go` — owned by
  a later phase (phase-03-per-level-provider-switch or equivalent).
- Chart / Helm secret wiring — owned by downstream phases.
- The integration demo Project manifest — owned by the final integration phase.

## Expected Deliverables

1. Go package `internal/subagent/codex` compiles cleanly with `go build ./internal/subagent/codex/...`.
2. `make test` remains green; offline tests in `*_test.go` cover the JSONL parser,
   the pricing computation, and the `Usage` normalisation paths.
3. No symbol from `internal/subagent/codex` appears in `internal/controller/` or
   `cmd/manager/` imports (enforced by `make verify-*`).
4. Apache 2.0 licence header on every `.go` file; logr/zap logging style; no
   `fmt.Print*` calls in production paths.

## Verification Gates

| Gate | Signal |
|------|--------|
| `go build ./internal/subagent/codex/...` exits 0 | Package scaffold compiles |
| `go vet ./internal/subagent/codex/...` exits 0 | No vet violations |
| `go test ./internal/subagent/codex/...` exits 0 (offline) | Unit tests pass |
| `grep -r '"internal/subagent/codex"' internal/controller/ cmd/manager/` empty | No leakage |
| `pricing.Compute` returns non-zero for known models | Pricing table populated |
| `Usage.CacheCreationTokens == 0` in all Run() test cases | OpenAI cache model correct |

## Wave Grouping (illustrative — authoritative wave derived from Task DAG by Kahn)

| Wave | Plans | Rationale |
|------|-------|-----------|
| 1 | plan-01-pkg-scaffold, plan-02-pricing | No intra-phase deps — can run in parallel |
| 2 | plan-03-run-impl | Requires client.go (plan-01) + pricing.go (plan-02) |
