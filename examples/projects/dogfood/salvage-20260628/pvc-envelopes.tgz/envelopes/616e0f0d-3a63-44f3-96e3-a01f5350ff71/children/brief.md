# Phase Brief — phase-03-codex-image-entrypoint

## Objective

Wire the Codex container's protocol bridge—the execution layer that reads a
TIDE `EnvelopeIn` from stdin, invokes `codex exec` with the correct headless
flags, parses the resulting JSONL event stream, and returns a fully-populated
`EnvelopeOut` to stdout. The phase delivers the one moving part that transforms
an idle `ghcr.io/jsquirrelz/tide-codex-subagent` image into a live TIDE
dispatch target—no provider-specific code escapes this package boundary.

## Scope

Bounded to `internal/subagent/codex/` and `cmd/codex-subagent/`. Relies on
the Go package skeleton (`client.go`, `doc.go`) authored in
`phase-02-codex-subagent-core` and the pricing table from
`phase-01-codex-pricing-usage`; does NOT touch the Dockerfile (owned by
`phase-02-codex-image-binary`) or the controller-side vendor switch (owned by
`phase-01-provider-switch`). All plans stay entirely behind the
`pkg/dispatch.Subagent` interface—zero Codex imports leak into
`internal/controller/` or `cmd/manager/`.

## Expected Deliverables

| Artifact | Description |
|---|---|
| `internal/subagent/codex/schema/output.schema.json` | JSON Schema passed to `codex exec --output-schema`; constrains the AI's final reply to valid child-CRD JSON |
| `internal/subagent/codex/parser.go` | JSONL event-stream scanner—finds the terminal `message` event, extracts text content + `usage` block (`prompt_tokens`, `completion_tokens`, `prompt_tokens_details.cached_tokens`) |
| `internal/subagent/codex/run.go` | `Subagent.Run(ctx, EnvelopeIn) (EnvelopeOut, error)` — builds the `codex exec` command, executes it, calls the parser, normalises usage via the pricing table into `pkg/dispatch.Usage`, returns `EnvelopeOut` |
| `cmd/codex-subagent/main.go` | Container ENTRYPOINT binary — JSON-decodes `EnvelopeIn` from stdin, calls `Subagent.Run()`, JSON-encodes `EnvelopeOut` to stdout |
| `internal/subagent/codex/parser_test.go` + `testdata/event_stream.jsonl` | Offline unit tests; real-API path guarded by `OPENAI_API_KEY` sentinel |

## Verification Gates

1. `make test` passes green — parser and run tests pass offline without
   `OPENAI_API_KEY` set.
2. `make verify-lint` / `make verify-fmt` clean — Apache 2.0 headers present,
   logr/zap logging, no `fmt.Print*` in production paths.
3. `go build ./cmd/codex-subagent/...` produces a static binary with no
   provider-specific imports visible outside `internal/subagent/codex/`.
4. The schema file is valid JSON Schema draft-07 and round-trips through
   `ajv validate` against a sample child-CRD JSON object.
5. `run.go` constructs a `codex exec` command that includes exactly:
   `--ephemeral`, `--skip-git-repo-check`, `--ignore-user-config`,
   `--sandbox workspace-write`, `--json`, `--output-schema <path>` — verified
   by inspecting the `exec.Cmd.Args` slice in the mock test.

## Wave Map (illustrative — authoritative derivation is Kahn over Task DAG)

| Wave | Plans | Rationale |
|---|---|---|
| 1 | `plan-01-output-schema` | Pure authoring; no code deps |
| 2 | `plan-02-jsonl-parser` | Depends on schema path constant from plan-01 |
| 3 | `plan-03-run-impl` | Depends on parser + schema; completes `Run()` |
| 4 | `plan-04-entrypoint-binary`, `plan-05-offline-tests` | Both depend on plan-03; independent of each other |
