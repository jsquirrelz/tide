# Phase Brief — phase-03-image-and-credentials

## Objective

Produce a deployable Codex subagent container image and wire all credential
material so that TIDE can dispatch Tasks to the Codex runtime under the same
Secret-ref discipline the Anthropic pool already uses — no operator workarounds,
no inlined secrets, no host-filesystem dependencies.

## Scope

This phase owns exactly two concerns that prior phases leave open:

1. **Container image** — `internal/subagent/codex/Dockerfile` must produce a
   minimal, hermetic image that bundles the Codex CLI binary and accepts the
   TIDE envelope entry-point, mirroring the multi-stage structure of
   `internal/subagent/anthropic/Dockerfile`. The final image is published under
   `ghcr.io/jsquirrelz/tide-codex-subagent:<tag>`.

2. **Credential wiring** — OPENAI_API_KEY must reach the running container via
   a K8s Secret whose *name only* is surfaced in Helm chart values under a new
   `codex.secretRef.name` key, mirroring the existing `anthropic.secretRef.name`
   convention. The controller's pod-spec builder (`dispatch_helpers.go`) must
   read that ref and inject the key as an env var — never mounting the Secret
   value into values.yaml or any manifest directly.

Out of scope for this phase (covered by adjacent phases):
- The Go subagent package (`client.go`, `run.go`, `pricing.go`) — phase-02
- The per-level vendor/provider switch in `ResolveProvider` — phase-04 and later
- End-to-end heterogeneous dispatch integration testing — phase-05+

## Expected Deliverables

| Deliverable | File(s) |
|---|---|
| Multi-stage Codex Dockerfile | `internal/subagent/codex/Dockerfile` |
| Helm chart values for Codex Secret name | `charts/tide/values.yaml` |
| Helm Secret template (or annotation) for Codex key | `charts/tide/templates/codex-secret.yaml` |
| Credential mount wiring in pod-spec builder | `internal/controller/dispatch_helpers.go` |

## Verification Gates

1. `docker build -f internal/subagent/codex/Dockerfile .` completes without
   error; `codex --version` runs successfully inside the resulting image.
2. `helm template tide charts/tide --set codex.secretRef.name=my-secret` renders
   without error and the rendered subagent Job manifest contains
   `valueFrom.secretKeyRef.name: my-secret`.
3. `make test` remains green — no new offline test touches a live OpenAI key.
4. `make verify-lint` and `make verify-fmt` remain green.
5. The Dockerfile contains no credentials, tokens, or host-path mounts;
   OPENAI_API_KEY is sourced exclusively from the referenced K8s Secret.

## Wave Map (illustrative — authoritative waves derived by Kahn over Task DAG)

| Wave | Plans | Rationale |
|---|---|---|
| 1 | plan-01-codex-dockerfile, plan-02-secret-chart-values | Independent — image build and chart values have no mutual dependency |
| 2 | plan-03-secret-mount-wiring | Reads Secret name from chart values (plan-02) and applies it in the controller pod-spec path |
