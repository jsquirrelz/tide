# Phase Brief — `phase-04-per-level-vendor-switch`

## Objective

Eliminate the hardcoded `Vendor:"anthropic"` return in `ResolveProvider`
(`internal/controller/dispatch_helpers.go`) and replace it with a live read
from the per-level `LevelConfig.Vendor` field in `SubagentConfig` — making
the controller truly provider-neutral and enabling mixed-provider waves where
planner-level Tasks route to Claude and executor-level Tasks route to Codex
(or any registered provider) without any controller rebuild.

## Context & Scope

This phase is the switching layer — it does NOT implement the Codex subagent
itself (that lives in `phase-01-codex-subagent-core` / `phase-02-*`) and does
NOT author the Helm chart credential wiring (that belongs to
`phase-05-chart-secret-wiring`). Its sole concern is the routing path from
"which level is this Task running at?" to "which `pkg/dispatch.Subagent`
implementation handles it?" — executed with zero provider imports in
`internal/controller/` and zero provider imports in `cmd/manager/`.

Scope includes:
- A `Vendor` (string, kubebuilder enum-validated) field on `LevelConfig`
  in `api/v1alpha2/project_types.go`.
- A `ProviderRegistry` + `SubagentFactory` interface in `pkg/dispatch/`
  — the controller-agnostic lookup layer that keeps the controller free of
  provider imports.
- Fixing `ResolveProvider` in `internal/controller/dispatch_helpers.go`
  to consult the registry with the per-level vendor string — replacing the
  `Vendor:"anthropic"` constant.
- A self-registering `internal/subagent/all/` aggregator package — blank-
  importing both `anthropic` and `codex` subagent packages — and a matching
  `cmd/manager/main.go` import so the composition root wires both factories
  without naming either provider in the controller or manager source.
- Unit tests (mock factories, offline, no real API calls) verifying that
  the routing logic correctly selects factories by vendor and falls back on
  misconfiguration.

Out of scope: Codex client implementation, Dockerfile, pricing table, Helm
Secret templates, and the end-to-end heterogeneous dispatch demo.

## Expected Deliverables

| Deliverable | File(s) |
|---|---|
| `Vendor` field on `LevelConfig` | `api/v1alpha2/project_types.go`, `api/v1alpha2/zz_generated.deepcopy.go` |
| Provider factory registry | `pkg/dispatch/registry.go` |
| Fixed `ResolveProvider` | `internal/controller/dispatch_helpers.go` |
| All-provider aggregator | `internal/subagent/all/all.go` |
| Manager wiring | `cmd/manager/main.go` |
| Routing unit tests | `internal/controller/dispatch_helpers_test.go`, `pkg/dispatch/registry_test.go` |

## Verification Gates

1. **`make generate`** — CRD manifests regenerate cleanly with the new
   `Vendor` enum field; no manual edits to generated files.
2. **`make verify-*` green** — lint, vet, and static checks pass; no
   provider-specific symbols appear in `internal/controller/` or
   `cmd/manager/` import graphs (verified by `go list -deps`).
3. **`make test` green** — new unit tests pass offline; existing tests
   remain unbroken; no real OpenAI API call executes without
   `OPENAI_API_KEY` set.
4. **Registry lookup contract** — a `ProviderRegistry` configured with
   both `"anthropic"` and `"openai"` factories returns the correct factory
   for each vendor string and returns an explicit error for unknown vendors.
5. **Controller import constraint** — `go list -deps ./internal/controller/...`
   and `go list -deps ./cmd/manager/...` contain no direct reference to
   `internal/subagent/codex` or `internal/subagent/anthropic` — only
   `pkg/dispatch` abstractions appear.
6. **Per-level routing smoke** — a Project spec with
   `subagentConfig.levels.plan.vendor: openai` and
   `subagentConfig.levels.task.vendor: anthropic` resolves to different
   factories at the two levels — confirmed by unit test assertions.

## Wave Map (illustrative — authoritative waves derive from Task DAG via Kahn)

| Wave | Plans |
|---|---|
| 1 | `plan-01-levelconfig-vendor-field`, `plan-02-provider-registry` |
| 2 | `plan-03-resolve-provider-switch`, `plan-04-provider-registration` |
| 3 | `plan-05-switch-tests` |
