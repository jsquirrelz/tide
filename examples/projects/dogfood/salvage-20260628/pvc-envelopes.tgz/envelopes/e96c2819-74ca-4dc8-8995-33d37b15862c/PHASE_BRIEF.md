# Phase Brief — phase-03-per-level-provider-switch

## Objective

Lift the unconditional `Vendor:"anthropic"` hardcode out of `ResolveProvider`
(internal/controller/dispatch_helpers.go) and replace it with a per-level
vendor derivation that honours the `SubagentConfig.Levels.{Milestone,Phase,
Plan,Task}` LevelConfig overrides already present in the v1alpha2 API schema.
When this phase lands, an operator who sets a Codex image at the Task level
will receive a Codex-typed provider config — not a silently-ignored Anthropic
one — and the per-level `providerSecretRef` will route the correct API-key
Secret to each subagent pod. No provider identity crosses the
`pkg/dispatch.Subagent` interface boundary; no Codex-specific import touches
`internal/controller/` or `cmd/manager/`.

## Scope

- **In scope:** `api/v1alpha2` schema extension (explicit `Vendor` field on
  `LevelConfig`); CRD manifest regeneration; `ResolveProvider` rewrite;
  per-level `providerSecretRef` resolution inside the controller dispatch path;
  unit tests; `make test` / `make verify-*` green gate.
- **Out of scope:** The Codex subagent Go package itself (phase-02); Helm chart
  Secret values (phase-04); end-to-end heterogeneous demo run (phase-05).

## Expected Deliverables

1. `api/v1alpha2/project_types.go` — `Vendor string` field on `LevelConfig`,
   with an exhaustive `+kubebuilder:validation:Enum` marker (`anthropic`,
   `openai`); downstream `zz_generated.deepcopy.go` updated accordingly.
2. `config/crd/bases/` — regenerated CRD YAML reflecting the new field.
3. `internal/controller/dispatch_helpers.go` — `ResolveProvider` walks the
   level stack (task-level → global fallback) and returns the declared vendor;
   per-level `providerSecretRef` resolution follows the same walk.
4. `internal/controller/dispatch_helpers_test.go` — table-driven unit tests
   covering all four levels, mixed-level configs, and the global-fallback case;
   all tests pass offline (no live API calls).
5. `make test` and `make verify-*` exit 0 with the changes applied.

## Verification Gates

| Gate | Pass condition |
|------|---------------|
| Schema | `LevelConfig` carries `Vendor string` with enum marker; deepcopy regenerated |
| CRD | `make generate manifests` produces a clean diff (no unexpected fields removed) |
| ResolveProvider | Given `Levels.Task.Vendor = "openai"` + global `"anthropic"`, returns `"openai"` for Task tasks and `"anthropic"` for others |
| Secret routing | Dispatcher selects per-level `providerSecretRef` when set; falls back to global |
| Offline test suite | `make test` green — zero skips attributable to missing `OPENAI_API_KEY` |
| Lint / vet | `make verify-*` exits 0; no new `golangci-lint` violations |

## Wave Sketch (illustrative — authoritative DAG derived by Kahn over Tasks)

```
Wave 1  [plan-01-schema-vendor-field]
Wave 2  [plan-02-resolve-provider-impl]   ← depends on plan-01
Wave 3  [plan-03-provider-switch-tests]   ← depends on plan-02
```
