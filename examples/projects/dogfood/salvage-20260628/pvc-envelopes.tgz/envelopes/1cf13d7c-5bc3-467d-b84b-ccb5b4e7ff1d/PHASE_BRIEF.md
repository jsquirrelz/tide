# Phase Brief — phase-05-chart-secret-wiring

## Objective

Wire the Helm chart (`charts/tide/`) to surface a first-class, operator-facing
credential path for the Codex (OpenAI) subagent — adding `codexProvider`
values, per-level secret-ref injection into subagent pod specs, RBAC entries,
and a worked example Project CR that demonstrates a planner-Claude /
executor-Codex split — so that an operator can activate heterogeneous dispatch
by setting two Secret names and two image references in `values.yaml`, with no
code changes and no secret material inlined in any manifest.

## Scope

This phase is narrowly chart-and-operator-surface only.  It does **not**
touch the Codex Go package (`internal/subagent/codex/`) — that is Phase 02 —
nor the `ResolveProvider` controller path — that is Phase 03.  This phase
consumes both of those as prerequisites and exposes their work to cluster
operators through the established Helm + Secret-ref idiom.

Concretely in scope:
- `charts/tide/values.yaml` and `values.schema.json` — new `codexProvider`
  subtree with `secretRef.name` and per-level image override examples.
- Chart templates — conditional `envFrom`/`env` injection so that subagent
  pods at codex-designated levels receive `OPENAI_API_KEY` from the named
  Secret; anthropic-designated levels are unaffected.
- RBAC — extend the manager ClusterRole (or a new Role) to `get`/`list` the
  Codex Secret; keep the existing anthropic Secret grant intact.
- Example Project CR (`config/samples/mixed-provider-project.yaml`) —
  demonstrates `subagentConfig.levels.task.image` = codex image +
  `subagentConfig.levels.task.providerSecretRef.name` = codex-secret,
  with planner levels using the anthropic image.
- Helm CI values file and lint pass — `helm lint --strict` must pass with the
  new chart additions.

Out of scope: Go implementation, DAG changes, dashboard changes, metrics.

## Expected Deliverables

| Artifact | Location |
|---|---|
| Updated chart values + schema | `charts/tide/values.yaml`, `charts/tide/values.schema.json` |
| Subagent pod-spec template update | `charts/tide/templates/` (job or pod template) |
| RBAC extension for Codex secret | `charts/tide/templates/rbac.yaml` or equivalent |
| Helm CI codex-specific values | `charts/tide/ci/codex-values.yaml` |
| Mixed-provider sample Project CR | `config/samples/mixed-provider-project.yaml` |
| Chart README update | `charts/tide/README.md` |

## Verification Gates

1. **`helm lint --strict charts/tide/`** passes with codex values wired — zero
   warnings on the new `codexProvider` stanza and templates.
2. **`helm template tide charts/tide/ -f charts/tide/ci/codex-values.yaml`**
   renders without error; the rendered subagent pod spec contains the
   `envFrom` secretRef entry keyed to the codex secret name.
3. **`make verify-*` guard suite remains green** — no regressions to existing
   anthropic-path chart rendering.
4. **Secret name is never inlined** in any rendered manifest — confirmed by
   `grep -r 'OPENAI_API_KEY\|sk-' charts/tide/templates/` returning zero hits.
5. **Sample Project CR validates** against the v1alpha2 CRD schema — confirmed
   by `kubectl apply --dry-run=client` against the installed CRD.

## Wave Structure (illustrative — Kahn derives authoritatively)

| Wave | Plans |
|---|---|
| 1 | `plan-01-codex-values-schema` |
| 2 | `plan-02-codex-template-env`, `plan-03-codex-rbac-secret` |
| 3 | `plan-04-codex-sample-cr`, `plan-05-codex-chart-verify` |
