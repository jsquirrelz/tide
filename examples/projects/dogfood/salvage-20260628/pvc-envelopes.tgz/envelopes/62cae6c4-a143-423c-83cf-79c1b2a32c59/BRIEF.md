# Phase Brief — phase-02-codex-subagent-core

## Objective

Deliver the complete `internal/subagent/codex/` Go package — the pure-library
layer implementing `pkg/dispatch.Subagent` for the OpenAI/Codex runtime.  The
package is a provider-encapsulated mirror of `internal/subagent/anthropic/`;
every Codex-specific concern — subprocess invocation of the Codex CLI, JSONL
event-stream parsing, Usage normalization, and per-model cost accounting — stays
entirely within this package and behind the shared `pkg/dispatch.Subagent`
interface.  No controller changes, no Dockerfile, no chart wiring belong here.

## Scope

- `internal/subagent/codex/doc.go` — package declaration + Apache 2.0 header,
  commentary referencing the D-C1 layering pattern.
- `internal/subagent/codex/client.go` — `Client` struct and constructor; drives
  `codex exec --ephemeral --skip-git-repo-check --ignore-user-config --json
  --sandbox workspace-write` as a subprocess; collects the JSONL event stream
  and surfaces the final-message payload plus the raw usage block.
- `internal/subagent/codex/pricing.go` — per-model cents/MTok pricing table
  mirroring `internal/subagent/anthropic/pricing.go`; normalizes the OpenAI
  usage block into `pkg/dispatch.Usage` — `CacheReadTokens` ←
  `prompt_tokens_details.cached_tokens`, `CacheCreationTokens` always 0
  (OpenAI caching is automatic and marker-free).
- `internal/subagent/codex/run.go` — `Subagent` struct (wraps `Client`);
  implements `Subagent.Run(ctx, EnvelopeIn) (EnvelopeOut, error)` — marshals
  the envelope prompt into the CLI invocation, captures output, populates
  `EnvelopeOut` + `pkg/dispatch.Usage` via the pricing table, logs with
  `logr`/`zap`.
- `internal/subagent/codex/*_test.go` — offline unit tests: mock subprocess
  runner verifying JSONL parsing and error paths; pricing table accuracy;
  Usage field mapping — `EstimatedCostCents`, `CacheSavingsCents`,
  `CacheCreationTokens == 0`.  Any test that issues a live OpenAI call MUST be
  gated on `OPENAI_API_KEY` env being set.

Out of scope for this phase: the Codex container image / Dockerfile
(`internal/subagent/codex/Dockerfile`), the per-level `ResolveProvider` fix in
`internal/controller/dispatch_helpers.go`, Helm chart credential wiring, and
the integration smoke-test — those belong to later phases.

## Expected Deliverables

| Artefact | Location |
|---|---|
| Package doc | `internal/subagent/codex/doc.go` |
| Client | `internal/subagent/codex/client.go` |
| Pricing + Usage normalizer | `internal/subagent/codex/pricing.go` |
| Subagent.Run | `internal/subagent/codex/run.go` |
| Unit tests | `internal/subagent/codex/run_test.go`, `internal/subagent/codex/pricing_test.go` |

## Verification Gates

1. **`make test` green** — all pre-existing tests pass; new tests pass without
   `OPENAI_API_KEY` set (offline mode).
2. **`make verify-*` / `go vet ./internal/subagent/codex/...`** — no lint or
   vet errors; Apache 2.0 header present in every new file.
3. **Zero controller leakage** — `grep -r "codex\|openai" internal/controller/
   cmd/manager/` emits no new hits.
4. **Usage struct fully populated** — unit test asserts all six fields
   (`InputTokens`, `OutputTokens`, `CacheReadTokens`, `CacheCreationTokens=0`,
   `EstimatedCostCents>0`, `CacheSavingsCents`) from a mocked response with
   `prompt_tokens_details.cached_tokens > 0`.
5. **Interface satisfaction** — `var _ pkg_dispatch.Subagent = (*Subagent)(nil)`
   compile-time assertion present in run.go.

## Wave Groupings (illustrative — authoritative order derived from Task DAG)

| Wave | Plans |
|---|---|
| 1 | plan-01-pkg-scaffold, plan-02-client, plan-03-pricing |
| 2 | plan-04-run |
| 3 | plan-05-unit-tests |
